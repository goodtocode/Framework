﻿-- New role that allows Stored Procedure execution
--CREATE ROLE db_executor
--Go
--GRANT EXECUTE TO db_executor
--Go