﻿CREATE SCHEMA [CustomerCode]
    AUTHORIZATION [dbo];

